import { ScrollProgress } from "@/components/scroll-progress"
import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { ProtecaoVeicular } from "@/components/protecao-veicular"
import { Coberturas } from "@/components/coberturas"
import { Comparativo } from "@/components/comparativo"
import { Planos } from "@/components/planos"
import { SocialProof } from "@/components/social-proof"
import { SimulationForm } from "@/components/simulation-form"
import { QuemSomos } from "@/components/quem-somos"
import { Footer } from "@/components/footer"

export default function App() {
  return (
    <>
      <ScrollProgress />
      <Header />
      <main>
        <Hero />
        <ProtecaoVeicular />
        <Coberturas />
        <Comparativo />
        <Planos />
        <SocialProof />
        <SimulationForm />
        <QuemSomos />
      </main>
      <Footer />
    </>
  )
}
