import { motion, useInView, useMotionValue, animate } from "framer-motion"
import { useRef, useEffect, useState } from "react"
import { Star, Quote } from "lucide-react"

function AnimatedCounter({
  target,
  suffix = "",
  decimals = 0,
}: {
  target: number
  suffix?: string
  decimals?: number
}) {
  const [display, setDisplay] = useState("0")
  const ref = useRef(null)
  const inView = useInView(ref, { once: true })
  const motionValue = useMotionValue(0)

  useEffect(() => {
    if (inView) {
      const controls = animate(motionValue, target, {
        duration: 2.5,
        ease: [0.22, 1, 0.36, 1],
      })
      const unsubscribe = motionValue.on("change", (v) => {
        if (decimals > 0) {
          setDisplay(v.toFixed(decimals))
        } else {
          setDisplay(Math.round(v).toLocaleString("pt-BR"))
        }
      })
      return () => {
        controls.stop()
        unsubscribe()
      }
    }
  }, [inView, motionValue, target, decimals])

  return (
    <span ref={ref} className="tabular-nums">
      {display}{suffix}
    </span>
  )
}

const stats = [
  { value: 50000, suffix: "+", label: "Clientes protegidos", color: "text-solidy-green" },
  { value: 98, suffix: "%", label: "Satisfação dos clientes", color: "text-solidy-yellow-dark" },
  { value: 15000, suffix: "+", label: "Sinistros resolvidos", color: "text-solidy-blue" },
  { value: 4.9, suffix: "", label: "Avaliação média", color: "text-solidy-green", decimals: 1 },
]

const testimonials = [
  {
    name: "Maria Silva",
    role: "Empresária",
    content: "A Solidy mudou minha experiência com seguro auto. Processo rápido, atendimento excelente e preço justo.",
    rating: 5,
  },
  {
    name: "Carlos Oliveira",
    role: "Engenheiro",
    content: "Tive um sinistro e fui atendido em menos de 20 minutos. O carro reserva chegou no mesmo dia.",
    rating: 5,
  },
  {
    name: "Ana Santos",
    role: "Médica",
    content: "Cotei em várias seguradoras e a Solidy ofereceu o melhor custo-benefício. Processo digital muito prático.",
    rating: 5,
  },
]

export function SocialProof() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: "-80px" })

  return (
    <section id="depoimentos" className="relative bg-background py-20 lg:py-32 overflow-hidden">
      <div className="pointer-events-none absolute top-0 right-0 h-72 w-72 rounded-full bg-solidy-green/5 -translate-y-1/3 translate-x-1/3" />

      <div ref={ref} className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="mb-8 text-center"
        >
          <motion.span
            initial={{ opacity: 0, scale: 0.9 }}
            animate={inView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="inline-block rounded-full bg-solidy-blue/10 px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-solidy-blue"
          >
            Números que falam
          </motion.span>
        </motion.div>

        {/* Stats grid — sempre 2 colunas no mobile, 4 no desktop */}
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-5 mb-16 sm:mb-20">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30, scale: 0.9 }}
              animate={inView ? { opacity: 1, y: 0, scale: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.12 * i, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ scale: 1.04, y: -3 }}
              className="rounded-2xl border border-border bg-card p-4 text-center shadow-sm hover:shadow-lg transition-shadow sm:p-6"
            >
              <p className={`text-2xl font-bold leading-none sm:text-3xl lg:text-4xl ${stat.color}`}>
                <AnimatedCounter
                  target={stat.value}
                  suffix={stat.suffix}
                  decimals={stat.decimals ?? 0}
                />
              </p>
              <p className="mt-2 text-xs leading-snug text-muted-foreground sm:text-sm">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        <div className="mb-8 text-center">
          <h2 className="text-2xl font-bold text-foreground sm:text-3xl">O que nossos clientes dizem</h2>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 sm:gap-6">
          {testimonials.map((testimonial, i) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              animate={inView ? { opacity: 1, y: 0, scale: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.3 + 0.12 * i }}
              whileHover={{ y: -5 }}
              className="relative h-full rounded-2xl border border-border bg-card p-5 transition-shadow hover:shadow-xl sm:p-6"
            >
              <Quote className="mb-3 h-6 w-6 text-solidy-yellow/30 sm:h-8 sm:w-8 sm:mb-4" />
              <p className="text-sm leading-relaxed text-muted-foreground">{testimonial.content}</p>
              <div className="mt-5 flex items-center gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-solidy-green/10 text-sm font-bold text-solidy-green">
                  {testimonial.name.charAt(0)}
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-foreground">{testimonial.name}</p>
                  <p className="text-xs text-muted-foreground">{testimonial.role}</p>
                </div>
                <div className="ml-auto flex gap-0.5 shrink-0">
                  {Array.from({ length: testimonial.rating }).map((_, j) => (
                    <Star key={j} className="h-3.5 w-3.5 fill-solidy-yellow text-solidy-yellow" />
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
