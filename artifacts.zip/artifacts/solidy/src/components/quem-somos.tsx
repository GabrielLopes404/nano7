import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Award } from "lucide-react"

const certs = [
  { code: "ISO 9001", desc: "Qualidade dos Processos" },
  { code: "ISO 37001", desc: "Gestão Antissuborno" },
  { code: "ISO 10002", desc: "Satisfação do Cliente" },
]

const pilares = [
  { num: "01", titulo: "Consultores capacitados", desc: "Comprometidos com cada associado em cada etapa." },
  { num: "02", titulo: "Colaboradores especializados", desc: "Equipe interna pronta em toda a jornada do associado." },
  { num: "03", titulo: "Rede credenciada sólida", desc: "Pronta para atender em qualquer situação no país." },
]

export function QuemSomos() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: "-80px" })

  return (
    <section id="quem-somos" className="relative bg-background py-20 lg:py-32 overflow-hidden">
      <div className="pointer-events-none absolute -top-20 -right-20 h-64 w-64 rounded-full bg-solidy-blue/5" />
      <div className="pointer-events-none absolute -bottom-20 -left-20 h-56 w-56 rounded-full bg-solidy-green/5" />

      <div ref={ref} className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="mb-14 text-center"
        >
          <span className="mb-3 inline-block text-xs font-bold uppercase tracking-[0.2em] text-solidy-green">
            Nossa história
          </span>
          <h2 className="text-3xl font-black tracking-tight text-foreground sm:text-4xl lg:text-5xl">
            Quem Somos
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
            A Solidy Benefícios é uma associação de socorro mútuo sem fins lucrativos, reconhecida pela credibilidade, inovação e excelência.
          </p>
        </motion.div>

        <div className="grid gap-5 lg:grid-cols-2 lg:gap-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.65, delay: 0.2 }}
          >
            <div className="rounded-2xl border border-border bg-card p-6 shadow-sm sm:p-8">
              <p className="mb-4 text-sm leading-relaxed text-muted-foreground sm:text-base">
                Nossa atuação vai além da proteção: entregamos experiências reais de cuidado, promovemos impacto social e construímos conexões duradouras com cada associado.
              </p>
              <p className="mb-6 text-sm leading-relaxed text-muted-foreground sm:text-base sm:mb-8">
                Com essa estrutura, conquistamos a confiança de milhares de famílias em todo o país, fortalecendo a Solidy como referência no setor.
              </p>
              <div className="rounded-xl bg-solidy-green/5 border border-solidy-green/12 p-5">
                <p className="text-[10px] font-bold uppercase tracking-widest text-solidy-green mb-2">Nosso Propósito</p>
                <p className="text-sm font-medium text-foreground italic leading-relaxed">
                  "Surpreender o associado com a melhor experiência resolutiva e empática, por meio de serviços cada vez mais completos, integrados e sustentáveis."
                </p>
              </div>
              <div className="mt-6">
                {pilares.map((p, i) => (
                  <motion.div
                    key={p.num}
                    initial={{ opacity: 0, y: 10 }}
                    animate={inView ? { opacity: 1, y: 0 } : {}}
                    transition={{ delay: 0.4 + i * 0.1 }}
                    className="flex gap-4 border-b border-border py-3.5 first:border-t"
                  >
                    <span className="text-xs font-bold tabular-nums text-muted-foreground mt-0.5">{p.num}</span>
                    <div>
                      <p className="text-sm font-bold text-foreground">{p.titulo}</p>
                      <p className="text-xs text-muted-foreground">{p.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.65, delay: 0.3 }}
            className="flex flex-col gap-5"
          >
            <div className="rounded-2xl border border-border bg-card p-6 shadow-sm sm:p-8">
              <div className="mb-5 flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-solidy-yellow/15 ring-4 ring-solidy-yellow/10">
                  <Award className="h-5 w-5 text-solidy-yellow-dark" />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Certificações</p>
                  <h3 className="text-base font-bold text-foreground sm:text-lg">Primeira associação goiana certificada</h3>
                </div>
              </div>
              {/* Certs — 3 colunas sempre, mas menores no mobile */}
              <div className="grid grid-cols-3 gap-2 sm:gap-4">
                {certs.map((c, i) => (
                  <motion.div
                    key={c.code}
                    initial={{ opacity: 0, scale: 0.85 }}
                    animate={inView ? { opacity: 1, scale: 1 } : {}}
                    transition={{ delay: 0.5 + i * 0.1, type: "spring", stiffness: 300 }}
                    whileHover={{ scale: 1.04, y: -2 }}
                    className="flex flex-col items-center justify-center rounded-xl border border-border bg-muted/50 p-3 text-center sm:p-4"
                  >
                    <p className="text-xs font-bold text-solidy-green leading-tight sm:text-sm">{c.code}</p>
                    <p className="mt-1 text-[10px] text-muted-foreground leading-tight">{c.desc}</p>
                  </motion.div>
                ))}
              </div>
              <p className="mt-3 text-xs text-muted-foreground">Além da AAPV, FAN e muito mais.</p>
            </div>

            <div className="rounded-2xl border border-border bg-card p-6 shadow-sm sm:p-8">
              <p className="text-[10px] font-bold uppercase tracking-widest text-solidy-blue mb-2">Nossa Missão</p>
              <p className="text-sm leading-relaxed text-muted-foreground sm:text-base">
                Proporcionar <strong className="text-foreground">tranquilidade, confiança e soluções inovadoras</strong>, construindo vínculos sólidos com associados, colaboradores e parceiros.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
