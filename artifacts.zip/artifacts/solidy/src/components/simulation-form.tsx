import { motion, useInView } from "framer-motion"
import { useRef, useState } from "react"
import { Loader2, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const WHATSAPP_NUMBER = "5561996059681"

const currentYear = new Date().getFullYear()
const years = Array.from({ length: 30 }, (_, i) => currentYear - i)

interface FormData {
  nome: string
  telefone: string
  email: string
  modelo: string
  ano: string
}

function buildWhatsAppMessage(data: FormData) {
  return encodeURIComponent(
    `Olá, Solidy! Quero receber uma cotação de proteção veicular.\n\n` +
    `👤 *Nome:* ${data.nome}\n` +
    `📱 *Telefone:* ${data.telefone}\n` +
    `📧 *E-mail:* ${data.email}\n` +
    `🚗 *Veículo:* ${data.modelo}\n` +
    `📅 *Ano:* ${data.ano}\n\n` +
    `Aguardo o contato!`
  )
}

export function SimulationForm() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: "-100px" })
  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [form, setForm] = useState<FormData>({ nome: "", telefone: "", email: "", modelo: "", ano: "" })

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!form.ano) return
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      setSubmitted(true)
      const msg = buildWhatsAppMessage(form)
      window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`, "_blank")
    }, 1200)
  }

  return (
    <section id="simulacao" className="relative overflow-hidden py-20 lg:py-36">
      <div className="absolute inset-0 bg-gradient-to-br from-[oklch(0.52_0.22_152_/_0.05)] via-background to-[oklch(0.38_0.18_264_/_0.03)]" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">

          {/* Lado esquerdo */}
          <motion.div
            ref={ref}
            initial={{ opacity: 0, x: -20 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-solidy-blue/20 bg-solidy-blue/8 px-4 py-1.5">
              <div className="h-1.5 w-1.5 rounded-full bg-solidy-blue animate-pulse" />
              <span className="text-sm font-semibold uppercase tracking-widest text-solidy-blue">Simulação gratuita</span>
            </div>
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl lg:text-5xl">
              Receba sua cotação{" "}
              <span className="text-solidy-green">em 1 minuto</span>
            </h2>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground sm:text-lg">
              Preencha seus dados e um especialista entra em contato pelo WhatsApp com as melhores condições.
            </p>

            <div className="mt-8 flex flex-col gap-4">
              {[
                { n: "01", title: "Preencha o formulário", desc: "Leva menos de 1 minuto." },
                { n: "02", title: "Receba sua cotação", desc: "Contato imediato pelo WhatsApp." },
                { n: "03", title: "Escolha e ative", desc: "Proteção ativa ainda hoje." },
              ].map((step) => (
                <div key={step.n} className="flex items-start gap-4">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-solidy-green/10 text-xs font-black text-solidy-green ring-4 ring-solidy-green/10">
                    {step.n}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-foreground">{step.title}</p>
                    <p className="text-sm text-muted-foreground">{step.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Formulário */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="rounded-3xl border border-border bg-card p-6 shadow-xl sm:p-8">
              {submitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center py-10 text-center"
                >
                  <div className="flex h-20 w-20 items-center justify-center rounded-full bg-solidy-green/10 ring-8 ring-solidy-green/10">
                    <MessageCircle className="h-9 w-9 text-solidy-green" />
                  </div>
                  <h3 className="mt-5 text-xl font-bold text-foreground">Mensagem enviada!</h3>
                  <p className="mt-2 text-sm text-muted-foreground max-w-xs">
                    Abrimos o WhatsApp com sua solicitação. Um especialista responderá em instantes!
                  </p>
                  <Button
                    className="mt-6 bg-solidy-green text-white hover:bg-solidy-green-hover"
                    onClick={() => setSubmitted(false)}
                  >
                    Nova simulação
                  </Button>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                  <div>
                    <h3 className="text-lg font-bold text-foreground">Simule agora</h3>
                    <p className="text-sm text-muted-foreground">Gratuito e sem compromisso.</p>
                  </div>

                  {/* Nome — largura total */}
                  <div>
                    <Label className="text-sm font-medium text-foreground">Nome completo</Label>
                    <Input
                      name="nome"
                      required
                      value={form.nome}
                      onChange={handleChange}
                      className="mt-1.5 h-12 border-border bg-background"
                      placeholder="Seu nome"
                    />
                  </div>

                  {/* Telefone e E-mail — lado a lado só em sm+ */}
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <Label className="text-sm font-medium text-foreground">Telefone / WhatsApp</Label>
                      <Input
                        name="telefone"
                        required
                        type="tel"
                        value={form.telefone}
                        onChange={handleChange}
                        className="mt-1.5 h-12 border-border bg-background"
                        placeholder="(00) 00000-0000"
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-foreground">E-mail</Label>
                      <Input
                        name="email"
                        required
                        type="email"
                        value={form.email}
                        onChange={handleChange}
                        className="mt-1.5 h-12 border-border bg-background"
                        placeholder="seu@email.com"
                      />
                    </div>
                  </div>

                  {/* Modelo e Ano — lado a lado só em sm+ */}
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <Label className="text-sm font-medium text-foreground">Marca / Modelo</Label>
                      <Input
                        name="modelo"
                        required
                        value={form.modelo}
                        onChange={handleChange}
                        className="mt-1.5 h-12 border-border bg-background"
                        placeholder="Ex: Honda Civic"
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-foreground">Ano</Label>
                      <Select required onValueChange={(v) => setForm((p) => ({ ...p, ano: v }))}>
                        <SelectTrigger className="mt-1.5 h-12 border-border bg-background">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          {years.map((year) => (
                            <SelectItem key={year} value={String(year)}>{year}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    disabled={loading}
                    className="mt-1 h-14 bg-solidy-green text-white hover:bg-solidy-green-hover text-base font-semibold gap-2"
                  >
                    {loading ? (
                      <><Loader2 className="h-5 w-5 animate-spin" />Aguarde...</>
                    ) : (
                      <><MessageCircle className="h-5 w-5" />Receber cotação pelo WhatsApp</>
                    )}
                  </Button>
                  <p className="text-center text-xs text-muted-foreground">
                    Ao enviar, você concorda com nossa Política de Privacidade.
                  </p>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
