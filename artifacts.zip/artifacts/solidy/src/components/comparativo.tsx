import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Check, X, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const itensProtecao = [
  "Aceita todos os veículos",
  "Zero burocracia",
  "Sem consulta SPC / SERASA",
  "Sem fins lucrativos",
  "Interesses coletivos",
  "Agilidade na contratação e atendimento",
]

const itensSeguro = [
  "Burocrático e demorado",
  "Analisa o perfil do motorista",
  "Oneroso no sinistro",
  "Não atende a todos",
  "Tem fins lucrativos",
]

const WHATSAPP_URL = `https://wa.me/5561996059681?text=${encodeURIComponent("Olá! Gostaria de saber mais sobre a Proteção Veicular da Solidy.")}`

export function Comparativo() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: "-80px" })

  return (
    <section id="comparativo" className="relative bg-background py-20 lg:py-36 overflow-hidden">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute right-0 top-0 h-full w-1/3 bg-gradient-to-l from-solidy-green/[0.03] to-transparent" />
        <div className="absolute -bottom-32 -left-32 h-[400px] w-[400px] rounded-full bg-solidy-blue/5" />
      </div>

      <div ref={ref} className="relative mx-auto max-w-7xl px-4 sm:px-6">
        {/* Cabeçalho */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="mb-14 text-center"
        >
          <span className="mb-3 inline-block text-xs font-bold uppercase tracking-[0.2em] text-solidy-blue">
            Entenda a diferença
          </span>
          <h2 className="text-3xl font-black tracking-tight text-foreground sm:text-4xl lg:text-5xl">
            Proteção Veicular{" "}
            <span className="text-solidy-green">vs</span>{" "}
            Seguro Auto
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-base text-muted-foreground sm:text-lg">
            Veja por que a Proteção Veicular é a escolha mais inteligente.
          </p>
        </motion.div>

        <div className="grid gap-5 sm:gap-6 lg:grid-cols-2">
          {/* PROTEÇÃO VEICULAR */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.65, delay: 0.15 }}
          >
            <div className="relative h-full overflow-hidden rounded-3xl border-2 border-solidy-green/35 bg-gradient-to-br from-solidy-green/6 via-background to-background shadow-md shadow-solidy-green/8">
              <div className="absolute right-4 top-4 sm:right-5 sm:top-5">
                <span className="rounded-full bg-solidy-green px-3 py-1 text-xs font-bold uppercase tracking-wider text-white shadow-sm">
                  Recomendado
                </span>
              </div>

              <div className="p-6 pb-5 sm:p-8 sm:pb-6">
                <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-solidy-green/12 ring-8 ring-solidy-green/8">
                  <Check className="h-6 w-6 text-solidy-green" strokeWidth={2.5} />
                </div>
                <h3 className="text-xl font-bold text-foreground sm:text-2xl">Proteção Veicular</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  Sistema de rateio onde os custos são divididos entre os associados. Resolução rápida com mínima burocracia.
                </p>
              </div>

              <div className="px-6 pb-6 sm:px-8 sm:pb-8">
                <div className="space-y-3">
                  {itensProtecao.map((item, i) => (
                    <motion.div
                      key={item}
                      initial={{ opacity: 0, x: -12 }}
                      animate={inView ? { opacity: 1, x: 0 } : {}}
                      transition={{ delay: 0.35 + i * 0.06 }}
                      className="flex items-center gap-3"
                    >
                      <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-solidy-green/12">
                        <Check className="h-3 w-3 text-solidy-green" strokeWidth={3} />
                      </div>
                      <span className="text-sm font-medium text-foreground">{item}</span>
                    </motion.div>
                  ))}
                </div>

                <Button
                  className="mt-7 w-full bg-solidy-green text-white hover:bg-solidy-green-hover font-semibold gap-2"
                  asChild
                >
                  <a href="#simulacao">
                    Quero a Proteção Veicular
                    <ArrowRight className="h-4 w-4" />
                  </a>
                </Button>
              </div>
            </div>
          </motion.div>

          {/* SEGURO AUTO */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.65, delay: 0.25 }}
          >
            <div className="relative h-full overflow-hidden rounded-3xl border border-border bg-muted/40">
              <div className="p-6 pb-5 sm:p-8 sm:pb-6">
                <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-muted ring-8 ring-border">
                  <X className="h-6 w-6 text-muted-foreground" strokeWidth={2.5} />
                </div>
                <h3 className="text-xl font-bold text-foreground sm:text-2xl">Seguro Auto</h3>
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Tradicional</p>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  Realizado por companhias fiscalizadas pela SUSEP. O valor anual varia conforme o perfil do motorista.
                </p>
              </div>

              <div className="px-6 pb-6 sm:px-8 sm:pb-8">
                <div className="space-y-3">
                  {itensSeguro.map((item, i) => (
                    <motion.div
                      key={item}
                      initial={{ opacity: 0, x: 12 }}
                      animate={inView ? { opacity: 1, x: 0 } : {}}
                      transition={{ delay: 0.45 + i * 0.06 }}
                      className="flex items-center gap-3"
                    >
                      <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-destructive/10">
                        <X className="h-3 w-3 text-destructive" strokeWidth={3} />
                      </div>
                      <span className="text-sm font-medium text-muted-foreground">{item}</span>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-7 rounded-2xl border border-border bg-background p-4 text-center">
                  <p className="text-xs text-muted-foreground">
                    O Seguro Auto pode <strong className="text-foreground">negar cobertura</strong> com base no seu perfil.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
