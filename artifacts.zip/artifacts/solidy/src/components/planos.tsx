import { useRef, useState } from "react"
import { motion, useInView, AnimatePresence } from "framer-motion"
import { Check, Plus, Car, Bike, MessageCircle, Star } from "lucide-react"
import { Button } from "@/components/ui/button"

const WHATSAPP_NUMBER = "5561996059681"

function buildWhatsAppUrl(planName: string) {
  const msg = encodeURIComponent(
    `Olá, Solidy! Tenho interesse no plano *${planName}*. Podem me passar mais informações?`
  )
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`
}

type Plan = {
  id: string
  nome: string
  subtitulo: string
  destaque?: boolean
  categoria: "carro" | "moto"
  cobertura: string[]
  assistencia?: string[]
  adicionais: string[]
}

const planos: Plan[] = [
  {
    id: "master",
    nome: "Solidy Master",
    subtitulo: "A proteção mais completa do mercado",
    destaque: true,
    categoria: "carro",
    cobertura: [
      "Proteção 100% da Tabela Fipe",
      "Roubo / Furto",
      "Colisão",
      "Incêndio proveniente de colisão",
      "Perda total / parcial",
      "Fenômenos da natureza",
      "Proteção para terceiros de R$ 200.000",
      "15 dias de carro reserva",
      "60% de cobertura de periféricos",
    ],
    assistencia: [
      "Guincho de 1.000 km",
      "Guincho ilimitado para colisão",
      "Socorro elétrico / mecânico",
      "Chaveiro 24h",
      "Hospedagem emergencial (1 diária, até 5 pessoas)",
      "Transporte executivo",
      "Auxílio na troca de pneus",
    ],
    adicionais: [
      "Assistência Profissional",
      "Carro reserva ilimitado – R$ 29,90",
      "Rastreador Localizo – R$ 49,90",
      "Futura Dependente – R$ 4,00/dependente",
      "Telemedicina – R$ 4,90/dependente",
    ],
  },
  {
    id: "personalite",
    nome: "Solidy Personalite",
    subtitulo: "Cobertura personalizada para o seu perfil",
    categoria: "carro",
    cobertura: [
      "Proteção 100% da Tabela Fipe",
      "Roubo / Furto",
      "Colisão",
      "Incêndio proveniente de colisão",
      "Perda total / parcial",
      "Fenômenos da natureza",
      "Futura",
    ],
    assistencia: [
      "Guincho de 400 km",
      "Guincho ilimitado para colisão",
      "Socorro elétrico / mecânico",
      "Chaveiro 24h",
      "Hospedagem emergencial",
      "Transporte executivo",
      "Auxílio na troca de pneus",
    ],
    adicionais: [
      "Carro reserva 15 dias – R$ 10,00",
      "Carro reserva ilimitado – R$ 29,90",
      "Proteção terceiros R$ 30k – R$ 12,50",
      "Proteção terceiros R$ 70k – R$ 25,00",
      "Periféricos – R$ 10,00",
      "Guincho de 1.000 km – R$ 25,00",
      "Rastreador Localizo – R$ 49,90",
      "Telemedicina – R$ 4,90/dependente",
    ],
  },
  {
    id: "economico",
    nome: "Socorro Econômico",
    subtitulo: "Proteção essencial com ótimo custo-benefício",
    categoria: "carro",
    cobertura: [
      "Proteção 100% da Tabela Fipe",
      "Roubo / Furto",
      "Colisão",
      "Incêndio proveniente de colisão",
      "Perda total / parcial",
      "Fenômenos da natureza",
      "Amigo Médico",
      "Moto reserva por 7 dias",
    ],
    adicionais: [
      "Moto reserva por 15 dias – R$ 15,00",
      "Proteção terceiros R$ 10k – R$ 10,00",
      "Proteção terceiros R$ 30k – R$ 35,00",
      "Assistência Profissional",
      "Rastreador Localizo – R$ 49,90",
      "Telemedicina – R$ 4,90/dependente",
    ],
  },
  {
    id: "uber",
    nome: "Socorro Uber / App",
    subtitulo: "Para motoristas de app, táxi e aluguel",
    categoria: "carro",
    cobertura: [
      "Proteção 100% da Tabela Fipe",
      "Roubo / Furto",
      "Colisão",
      "Incêndio proveniente de colisão",
      "Perda total / parcial",
      "Fenômenos da natureza",
      "Proteção para terceiros de R$ 200.000",
      "15 dias de carro reserva",
      "60% de cobertura de periféricos",
    ],
    adicionais: [
      "Carro reserva 15 dias – R$ 10,00",
      "Carro reserva ilimitado – R$ 29,90",
      "Proteção terceiros R$ 30k – R$ 12,50",
      "Proteção terceiros R$ 70k – R$ 25,00",
      "Periféricos – R$ 10,00",
      "Guincho de 1.000 km – R$ 25,00",
      "Rastreador Localizo – R$ 49,90",
      "Telemedicina – R$ 4,90/dependente",
    ],
  },
  {
    id: "motomaster",
    nome: "Motoclub Master",
    subtitulo: "Proteção premium para motociclistas",
    destaque: true,
    categoria: "moto",
    cobertura: [
      "Proteção 100% da Tabela Fipe",
      "Roubo / Furto",
      "Colisão",
      "Incêndio proveniente de colisão",
      "Perda total / parcial",
      "Fenômenos da natureza",
      "Proteção para terceiros de R$ 30.000",
      "Moto reserva por 22 dias",
    ],
    assistencia: [
      "Guincho de 400 km",
      "Guincho ilimitado para colisão",
      "Auxílio em pane seca",
      "Socorro elétrico / mecânico",
      "Chaveiro 24h",
      "Hospedagem emergencial",
    ],
    adicionais: [
      "Assistência Profissional",
      "Rastreador Localizo – R$ 49,90",
      "Telemedicina – R$ 4,90/dependente",
    ],
  },
  {
    id: "motopersonalite",
    nome: "Motoclub Personalite",
    subtitulo: "Proteção completa para sua moto",
    categoria: "moto",
    cobertura: [
      "Proteção 100% da Tabela Fipe",
      "Roubo / Furto",
      "Colisão",
      "Incêndio proveniente de colisão",
      "Perda total / parcial",
      "Fenômenos da natureza",
      "Amigo Médico",
      "Moto reserva por 7 dias",
    ],
    assistencia: [
      "Guincho de 400 km",
      "Guincho ilimitado para colisão",
      "Socorro elétrico / mecânico",
      "Chaveiro 24h",
      "Hospedagem emergencial (1 diária, 2 pessoas)",
      "Transporte executivo",
      "Auxílio na troca de pneus",
    ],
    adicionais: [
      "Moto reserva por 15 dias – R$ 15,00",
      "Proteção terceiros R$ 10k – R$ 10,00",
      "Proteção terceiros R$ 30k – R$ 35,00",
      "Rastreador Localizo – R$ 49,90",
      "Telemedicina – R$ 4,90/dependente",
    ],
  },
]

function PlanCard({ plan, index, inView }: { plan: Plan; index: number; inView: boolean }) {
  const [showAdicionais, setShowAdicionais] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: 0.1 + index * 0.1, ease: [0.22, 1, 0.36, 1] }}
      className="relative flex h-full flex-col"
    >
      {plan.destaque && (
        <div className="absolute -top-3.5 left-6 z-10">
          <span className="flex items-center gap-1.5 rounded-full bg-solidy-green px-3 py-1 text-xs font-bold text-white shadow-md shadow-solidy-green/30">
            <Star className="h-3 w-3 fill-current" />
            Mais popular
          </span>
        </div>
      )}

      <div
        className={`relative flex h-full flex-col overflow-hidden rounded-3xl border transition-all duration-300 hover:shadow-xl ${
          plan.destaque
            ? "border-solidy-green/40 bg-gradient-to-b from-solidy-green/5 to-white shadow-lg shadow-solidy-green/10"
            : "border-[#e4e8e2] bg-white shadow-sm hover:border-solidy-green/25"
        }`}
      >
        {/* Cabeçalho do plano */}
        <div className={`p-6 pb-5 ${plan.destaque ? "border-b border-solidy-green/15" : "border-b border-[#f0f3ee]"}`}>
          <h3 className="text-lg font-black text-foreground">{plan.nome}</h3>
          <p className="mt-1 text-xs font-medium text-muted-foreground leading-snug">{plan.subtitulo}</p>
        </div>

        {/* Coberturas */}
        <div className="flex-1 p-6">
          <p className="mb-3 text-[10px] font-bold uppercase tracking-widest text-solidy-green/70">Cobertura inclusa</p>
          <ul className="space-y-2.5">
            {plan.cobertura.map((item) => (
              <li key={item} className="flex items-start gap-2.5">
                <div className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-solidy-green/10">
                  <Check className="h-2.5 w-2.5 text-solidy-green" strokeWidth={3} />
                </div>
                <span className="text-xs font-medium text-foreground/80 leading-snug">{item}</span>
              </li>
            ))}
          </ul>

          {/* Assistência */}
          {plan.assistencia && plan.assistencia.length > 0 && (
            <div className="mt-5">
              <p className="mb-3 text-[10px] font-bold uppercase tracking-widest text-[oklch(0.58_0.20_88)]/70">Assistência 24h</p>
              <ul className="space-y-2">
                {plan.assistencia.map((item) => (
                  <li key={item} className="flex items-start gap-2.5">
                    <div className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-[oklch(0.87_0.22_88)/0.2]">
                      <Check className="h-2.5 w-2.5 text-[oklch(0.58_0.20_88)]" strokeWidth={3} />
                    </div>
                    <span className="text-xs font-medium text-foreground/80 leading-snug">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Adicionais colapsáveis */}
          <div className="mt-5">
            <button
              onClick={() => setShowAdicionais(!showAdicionais)}
              className="flex w-full items-center justify-between rounded-xl border border-dashed border-[#d0d8cb] px-3.5 py-2.5 text-left text-xs font-semibold text-muted-foreground transition-colors hover:border-solidy-green/40 hover:text-solidy-green"
            >
              <span className="flex items-center gap-2">
                <Plus className={`h-3.5 w-3.5 transition-transform duration-200 ${showAdicionais ? "rotate-45" : ""}`} />
                Benefícios adicionais
              </span>
              <span className="rounded-full bg-muted px-2 py-0.5 text-[10px]">{plan.adicionais.length}</span>
            </button>

            <AnimatePresence>
              {showAdicionais && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <ul className="mt-3 space-y-2 pl-1">
                    {plan.adicionais.map((item) => (
                      <li key={item} className="flex items-start gap-2">
                        <div className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-solidy-green/40" />
                        <span className="text-xs text-muted-foreground leading-snug">{item}</span>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* CTA */}
        <div className="p-6 pt-0">
          <Button
            className={`w-full gap-2 font-bold ${
              plan.destaque
                ? "bg-solidy-green text-white hover:bg-solidy-green-hover shadow-md shadow-solidy-green/20"
                : "bg-foreground text-background hover:bg-foreground/90"
            }`}
            asChild
          >
            <a href={buildWhatsAppUrl(plan.nome)} target="_blank" rel="noopener noreferrer">
              <MessageCircle className="h-4 w-4" />
              Quero este plano
            </a>
          </Button>
        </div>
      </div>
    </motion.div>
  )
}

export function Planos() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: "-60px" })
  const [categoria, setCategoria] = useState<"carro" | "moto">("carro")

  const filtered = planos.filter((p) => p.categoria === categoria)

  return (
    <section id="planos" className="relative overflow-hidden bg-[#f7f8f6] py-28 lg:py-36">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 -left-40 h-96 w-96 rounded-full bg-solidy-green/5" />
        <div className="absolute -bottom-20 -right-20 h-80 w-80 rounded-full bg-solidy-yellow/5" />
      </div>

      <div ref={ref} className="relative mx-auto max-w-7xl px-6">
        {/* Cabeçalho */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="mb-14 text-center"
        >
          <motion.span
            initial={{ opacity: 0 }}
            animate={inView ? { opacity: 1 } : {}}
            transition={{ delay: 0.1 }}
            className="mb-4 inline-block text-xs font-bold uppercase tracking-[0.2em] text-solidy-green"
          >
            Nossos planos
          </motion.span>
          <h2 className="text-4xl font-black tracking-tight text-foreground sm:text-5xl lg:text-6xl">
            Escolha o plano{" "}
            <span className="text-solidy-green">ideal para você</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-lg text-muted-foreground">
            Do básico ao mais completo — temos o plano certo para o seu veículo e o seu bolso.
          </p>
        </motion.div>

        {/* Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="mb-12 flex justify-center"
        >
          <div className="inline-flex rounded-2xl border border-[#e4e8e2] bg-white p-1.5 shadow-sm">
            {(["carro", "moto"] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoria(cat)}
                className={`flex items-center gap-2 rounded-xl px-6 py-2.5 text-sm font-bold transition-all duration-250 ${
                  categoria === cat
                    ? "bg-solidy-green text-white shadow-md shadow-solidy-green/25"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {cat === "carro" ? <Car className="h-4 w-4" /> : <Bike className="h-4 w-4" />}
                {cat === "carro" ? "Automóveis" : "Motocicletas"}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Grid de planos */}
        <AnimatePresence mode="wait">
          <motion.div
            key={categoria}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.35 }}
            className={`grid gap-5 ${
              filtered.length === 2
                ? "sm:grid-cols-2 max-w-3xl mx-auto"
                : "sm:grid-cols-2 lg:grid-cols-4"
            }`}
          >
            {filtered.map((plan, i) => (
              <PlanCard key={plan.id} plan={plan} index={i} inView={inView} />
            ))}
          </motion.div>
        </AnimatePresence>

        {/* Nota de rodapé */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 0.7 }}
          className="mt-10 text-center text-xs text-muted-foreground"
        >
          Valores e coberturas sujeitos a aprovação. Entre em contato para uma cotação personalizada.
        </motion.p>
      </div>
    </section>
  )
}
