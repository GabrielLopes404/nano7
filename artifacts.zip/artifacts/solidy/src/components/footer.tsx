import { Phone, Mail, MapPin, Instagram, Facebook, Youtube } from "lucide-react"

const footerLinks = {
  Produto: ["Proteção Veicular", "Assistência 24h", "Benefícios Exclusivos", "Cotação Online"],
  Empresa: ["Quem Somos", "Carreiras", "Blog", "Imprensa"],
  Suporte: ["Central de Ajuda", "Fale Conosco", "FAQ", "Política de Privacidade"],
}

const WHATSAPP_NUMBER = "5561996059681"
const WHATSAPP_MSG = encodeURIComponent("Olá! Gostaria de saber mais sobre a Proteção Veicular da Solidy.")

export function Footer() {
  return (
    <footer className="border-t border-border bg-background">
      {/* Faixa de contato em destaque */}
      <div className="border-b border-border bg-solidy-green/5">
        <div className="mx-auto max-w-7xl px-6 py-8">
          <div className="flex flex-col items-center justify-between gap-6 sm:flex-row">
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-solidy-green mb-1">Fale com a Solidy</p>
              <p className="text-sm text-muted-foreground">Estamos prontos para te atender agora mesmo.</p>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row">
              <a
                href={`tel:+${WHATSAPP_NUMBER}`}
                className="flex items-center gap-2.5 rounded-xl border border-border bg-card px-4 py-3 text-sm font-semibold text-foreground transition-all hover:border-solidy-green/40 hover:bg-solidy-green/5"
              >
                <Phone className="h-4 w-4 text-solidy-green" />
                (61) 99605-9681
              </a>
              <a
                href="mailto:contato@solidyprotecaoveicular.com"
                className="flex items-center gap-2.5 rounded-xl border border-border bg-card px-4 py-3 text-sm font-semibold text-foreground transition-all hover:border-solidy-blue/40 hover:bg-solidy-blue/5"
              >
                <Mail className="h-4 w-4 text-solidy-blue" />
                contato@solidyprotecaoveicular.com
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Corpo do footer */}
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-5">
          {/* Brand */}
          <div className="lg:col-span-2">
            <a href="#" className="mb-4 inline-flex">
              <img
                src="/images/solidy-logo-new.png"
                alt="Solidy Benefícios"
                className="h-14 w-auto object-contain"
              />
            </a>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
              Associação de socorro mútuo sem fins lucrativos. Proteção veicular completa com zero burocracia para você e sua família.
            </p>

            {/* Contato no corpo */}
            <div className="mt-6 flex flex-col gap-2.5">
              <a
                href={`https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MSG}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                <Phone className="h-4 w-4 text-solidy-green" />
                (61) 99605-9681
              </a>
              <a
                href="mailto:contato@solidyprotecaoveicular.com"
                className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                <Mail className="h-4 w-4 text-solidy-blue" />
                contato@solidyprotecaoveicular.com
              </a>
            </div>

            {/* Redes sociais */}
            <div className="mt-6 flex gap-3">
              {[
                { icon: Instagram, href: "#", label: "Instagram" },
                { icon: Facebook, href: "#", label: "Facebook" },
                { icon: Youtube, href: "#", label: "Youtube" },
              ].map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="flex h-9 w-9 items-center justify-center rounded-xl border border-border bg-muted text-muted-foreground transition-all hover:border-solidy-green/40 hover:bg-solidy-green/10 hover:text-solidy-green"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="mb-5 text-sm font-bold uppercase tracking-widest text-foreground">{title}</h4>
              <ul className="flex flex-col gap-3">
                {links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Rodapé final */}
        <div className="mt-16 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 md:flex-row">
          <p className="text-sm text-muted-foreground">© 2026 Solidy Benefícios. Todos os direitos reservados.</p>
          <div className="flex gap-6">
            <a href="#" className="text-sm text-muted-foreground transition-colors hover:text-foreground">Termos de Uso</a>
            <a href="#" className="text-sm text-muted-foreground transition-colors hover:text-foreground">Privacidade</a>
            <a href="#" className="text-sm text-muted-foreground transition-colors hover:text-foreground">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  )
}
