import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import {
  Car, Clock, Zap, Smartphone, Users, Sliders, Video, FileCheck
} from "lucide-react"

const features = [
  {
    icon: Car,
    titulo: "Carros, motos e caminhões",
    desc: "Qualquer veículo coberto, sem exceções.",
    accent: "bg-solidy-green",
    size: "large",
  },
  {
    icon: Clock,
    titulo: "Veículos com mais de 8 anos",
    desc: "Sem restrição de idade ou modelo.",
    accent: "bg-solidy-blue",
    size: "small",
  },
  {
    icon: Zap,
    titulo: "Combustão, perda total e leilão",
    desc: "Histórico difícil? Protegemos do jeito que está.",
    accent: "bg-solidy-yellow",
    size: "small",
  },
  {
    icon: Smartphone,
    titulo: "Motoristas de app",
    desc: "Pensado para quem vive do veículo.",
    accent: "bg-solidy-green",
    size: "small",
  },
  {
    icon: Sliders,
    titulo: "Planos 100% personalizados",
    desc: "Você monta o plano ideal para seu bolso.",
    accent: "bg-solidy-blue",
    size: "large",
  },
  {
    icon: Users,
    titulo: "Perfil não altera o valor",
    desc: "Idade e histórico não mudam seu preço.",
    accent: "bg-solidy-yellow",
    size: "small",
  },
  {
    icon: Video,
    titulo: "Vistoria online ou presencial",
    desc: "Você escolhe como realizar a vistoria.",
    accent: "bg-solidy-green",
    size: "small",
  },
  {
    icon: FileCheck,
    titulo: "Zero burocracia",
    desc: "Rápido, simples e sem papelada.",
    accent: "bg-solidy-blue",
    size: "small",
  },
]

export function ProtecaoVeicular() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: "-60px" })

  return (
    <section id="protecao" className="relative bg-white py-20 lg:py-36 overflow-hidden">
      {/* Detalhe de fundo */}
      <div
        className="pointer-events-none absolute right-0 top-0 h-full w-1/2"
        style={{
          background:
            "radial-gradient(ellipse at 80% 15%, oklch(0.52 0.22 152 / 0.05) 0%, transparent 55%)",
        }}
      />

      <div ref={ref} className="relative mx-auto max-w-7xl px-4 sm:px-6">
        {/* Cabeçalho */}
        <div className="mb-14 grid gap-8 lg:grid-cols-2 lg:items-end lg:mb-20">
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7 }}
          >
            <span className="mb-4 inline-block text-xs font-bold uppercase tracking-[0.2em] text-solidy-green">
              Por que escolher a Solidy
            </span>
            <h2 className="text-4xl font-black leading-[1.05] tracking-tight text-foreground sm:text-5xl xl:text-7xl">
              A proteção que<br />
              <em className="not-italic text-solidy-green">cabe no seu</em><br />
              bolso.
            </h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:pb-3"
          >
            <p className="text-base leading-relaxed text-foreground/65 sm:text-lg">
              Aceitamos qualquer veículo, qualquer perfil, qualquer situação.
              Proteção real, sem exclusões absurdas.
            </p>
            <a
              href="#simulacao"
              className="mt-6 inline-flex items-center gap-2 rounded-full bg-solidy-green px-6 py-3 text-sm font-bold text-white shadow-lg shadow-solidy-green/20 transition-all hover:scale-105 hover:shadow-solidy-green/40"
            >
              Simule gratuitamente →
            </a>
          </motion.div>
        </div>

        {/* Grade estilo editorial */}
        <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4 lg:gap-5">
          {features.map((f, i) => {
            const Icon = f.icon
            const isGreen = f.accent === "bg-solidy-green"
            const isYellow = f.accent === "bg-solidy-yellow"
            const isBlue = f.accent === "bg-solidy-blue"

            const accentText = isGreen
              ? "text-solidy-green"
              : isYellow
              ? "text-[oklch(0.58_0.20_88)]"
              : "text-solidy-blue"

            const accentBg = isGreen
              ? "bg-solidy-green/10"
              : isYellow
              ? "bg-[oklch(0.87_0.22_88)/0.15]"
              : "bg-solidy-blue/10"

            const topBorder = isGreen
              ? "before:bg-solidy-green"
              : isYellow
              ? "before:bg-[oklch(0.78_0.20_88)]"
              : "before:bg-solidy-blue"

            return (
              <motion.div
                key={f.titulo}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.55, delay: 0.06 * i, ease: [0.22, 1, 0.36, 1] }}
                whileHover={{ y: -5 }}
                className={`group relative flex flex-col gap-3 overflow-hidden rounded-2xl bg-[#f8faf7] p-5 sm:p-6 before:absolute before:top-0 before:left-0 before:right-0 before:h-[3px] ${topBorder} transition-shadow hover:shadow-lg`}
              >
                {/* Ícone */}
                <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${accentBg}`}>
                  <Icon className={`h-5 w-5 ${accentText}`} strokeWidth={1.5} />
                </div>

                {/* Número decorativo */}
                <span className="absolute top-4 right-4 text-[42px] font-black leading-none text-foreground/[0.04] select-none">
                  {String(i + 1).padStart(2, "0")}
                </span>

                {/* Texto */}
                <div>
                  <h3 className="text-sm font-bold leading-snug text-foreground sm:text-base">
                    {f.titulo}
                  </h3>
                  <p className="mt-1.5 text-xs leading-relaxed text-foreground/55 sm:text-sm">
                    {f.desc}
                  </p>
                </div>

                {/* Linha de hover */}
                <div
                  className={`absolute bottom-0 left-0 h-[2px] w-0 transition-all duration-500 group-hover:w-full ${
                    isGreen ? "bg-solidy-green/30" : isYellow ? "bg-[oklch(0.78_0.20_88)/0.3]" : "bg-solidy-blue/30"
                  }`}
                />
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
