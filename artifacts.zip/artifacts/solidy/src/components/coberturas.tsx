import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import {
  ShieldAlert, Wrench, Zap, Fuel, RefreshCw,
  Car, BedDouble, Users, Wind, Smartphone
} from "lucide-react"

const sinistros = [
  { icon: ShieldAlert, label: "Roubo e Furto" },
  { icon: Car, label: "Batidas e Colisões" },
  { icon: Users, label: "Indenização a terceiros" },
  { icon: Wind, label: "Fenômenos da natureza" },
]

const assistencia = [
  { icon: RefreshCw, label: "Guincho" },
  { icon: Wrench, label: "Pane Mecânica" },
  { icon: Zap, label: "Pane Elétrica" },
  { icon: Fuel, label: "Pane Seca" },
  { icon: Car, label: "Troca de Pneu" },
  { icon: Users, label: "Transporte Executivo" },
  { icon: BedDouble, label: "Hospedagem" },
  { icon: Smartphone, label: "Chaveiro 24h" },
]

export function Coberturas() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: "-80px" })

  return (
    <section id="coberturas" className="relative bg-[#f7f8f6] py-20 lg:py-36 overflow-hidden">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-solidy-green/5" />
        <div className="absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-solidy-yellow/5" />
      </div>

      <div ref={ref} className="relative mx-auto max-w-7xl px-4 sm:px-6">
        {/* Cabeçalho */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="mb-14 text-center"
        >
          <span className="mb-3 inline-block text-xs font-bold uppercase tracking-[0.2em] text-solidy-green">
            Coberturas completas
          </span>
          <h2 className="text-3xl font-black tracking-tight text-foreground sm:text-4xl lg:text-5xl">
            Benefícios para o{" "}
            <span className="text-solidy-green">seu automóvel</span>
          </h2>
          <p className="mx-auto mt-4 max-w-lg text-base text-muted-foreground sm:text-lg">
            Cobertura ampla contra sinistros e assistência 24h — para você nunca ficar na mão.
          </p>
        </motion.div>

        <div className="grid gap-5 lg:grid-cols-2 lg:gap-8">
          {/* SINISTROS */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.15 }}
          >
            <div className="h-full rounded-3xl border border-[#e4e8e2] bg-white p-6 shadow-sm sm:p-8">
              <div className="mb-6 flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-solidy-green/10">
                  <ShieldAlert className="h-5 w-5 text-solidy-green" />
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-solidy-green/60">Categoria 01</p>
                  <h3 className="text-lg font-bold text-foreground">Sinistros</h3>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {sinistros.map((item, i) => {
                  const Icon = item.icon
                  return (
                    <motion.div
                      key={item.label}
                      initial={{ opacity: 0, y: 10 }}
                      animate={inView ? { opacity: 1, y: 0 } : {}}
                      transition={{ delay: 0.3 + i * 0.07 }}
                      whileHover={{ y: -2 }}
                      className="group flex flex-col items-center gap-2.5 rounded-xl border border-[#eaede8] bg-[#f4f7f2] px-3 py-4 text-center transition-all hover:border-solidy-green/25 hover:bg-solidy-green/5"
                    >
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white shadow-sm ring-1 ring-[#dde5d9] group-hover:ring-solidy-green/25 transition-all">
                        <Icon className="h-4.5 w-4.5 text-solidy-green" strokeWidth={1.5} />
                      </div>
                      <p className="text-xs font-semibold text-foreground leading-tight">{item.label}</p>
                    </motion.div>
                  )
                })}
              </div>
            </div>
          </motion.div>

          {/* ASSISTÊNCIA 24H */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.25 }}
          >
            <div className="h-full rounded-3xl border border-[#e4e8e2] bg-white p-6 shadow-sm sm:p-8">
              <div className="mb-6 flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[oklch(0.87_0.22_88)/0.2]">
                  <RefreshCw className="h-5 w-5 text-[oklch(0.56_0.18_88)]" />
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-[oklch(0.56_0.18_88)]/60">Categoria 02</p>
                  <h3 className="text-lg font-bold text-foreground">Assistência 24h</h3>
                </div>
              </div>

              <div className="flex flex-col gap-2">
                {assistencia.map((item, i) => {
                  const Icon = item.icon
                  return (
                    <motion.div
                      key={item.label}
                      initial={{ opacity: 0, x: 12 }}
                      animate={inView ? { opacity: 1, x: 0 } : {}}
                      transition={{ delay: 0.35 + i * 0.05 }}
                      whileHover={{ x: 4 }}
                      className="group flex items-center gap-3 rounded-xl border border-[#f0f2ee] bg-[#fafbf9] px-4 py-3 transition-all hover:border-[oklch(0.78_0.20_88)/0.3] hover:bg-[oklch(0.98_0.03_88)]"
                    >
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[oklch(0.97_0.05_88)] ring-1 ring-[#ede8d0]">
                        <Icon className="h-3.5 w-3.5 text-[oklch(0.56_0.18_88)]" strokeWidth={1.5} />
                      </div>
                      <span className="text-sm font-semibold text-foreground">{item.label}</span>
                      <div className="ml-auto h-1.5 w-1.5 shrink-0 rounded-full bg-[#d4c870] group-hover:bg-[oklch(0.62_0.18_88)] transition-colors" />
                    </motion.div>
                  )
                })}
              </div>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mt-8 flex items-center justify-center gap-2 text-center"
        >
          <div className="h-2 w-2 rounded-full bg-solidy-green animate-pulse" />
          <p className="text-sm font-medium text-muted-foreground">
            Assistência <strong className="text-foreground">24h por dia, 7 dias por semana</strong>, em todo o Brasil.
          </p>
        </motion.div>
      </div>
    </section>
  )
}
