import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Menu, X, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

const navLinks = [
  { label: "Proteção", href: "#protecao" },
  { label: "Coberturas", href: "#coberturas" },
  { label: "Diferenciais", href: "#comparativo" },
  { label: "Quem Somos", href: "#quem-somos" },
]

const WHATSAPP_NUMBER = "5561996059681"
const WHATSAPP_MSG = encodeURIComponent("Olá! Gostaria de falar com um especialista da Solidy sobre proteção veicular. Pode me ajudar?")
const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MSG}`

export function Header() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white shadow-md border-b border-border"
          : "bg-white/95 backdrop-blur-md border-b border-border/40"
      }`}
    >
      <div className="mx-auto flex h-24 max-w-7xl items-center justify-between px-6">
        <a href="#" className="flex items-center overflow-hidden h-24">
          <img
            src="/images/solidy-logo-new.png"
            alt="Solidy Benefícios"
            className="h-40 w-auto object-contain object-left"
          />
        </a>

        <nav className="hidden items-center gap-8 md:flex">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <Button
            variant="outline"
            className="border-solidy-green text-solidy-green hover:bg-solidy-green hover:text-white transition-all duration-300 gap-2"
            asChild
          >
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">
              <MessageCircle className="h-4 w-4" />
              Fale com Especialista
            </a>
          </Button>
          <Button
            className="bg-solidy-green text-white hover:bg-solidy-green-hover font-semibold transition-all duration-300"
            asChild
          >
            <a href="#simulacao">Simular Agora</a>
          </Button>
        </div>

        <button
          className="flex md:hidden text-foreground"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label={mobileOpen ? "Fechar menu" : "Abrir menu"}
        >
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden border-t border-border bg-white md:hidden"
          >
            <div className="flex flex-col gap-1 px-6 py-4">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
                >
                  {link.label}
                </a>
              ))}
              <div className="mt-4 flex flex-col gap-3">
                <Button
                  variant="outline"
                  className="border-solidy-green text-solidy-green hover:bg-solidy-green hover:text-white gap-2"
                  asChild
                >
                  <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer" onClick={() => setMobileOpen(false)}>
                    <MessageCircle className="h-4 w-4" />
                    Fale com Especialista
                  </a>
                </Button>
                <Button
                  className="bg-solidy-green text-white hover:bg-solidy-green-hover font-semibold"
                  asChild
                >
                  <a href="#simulacao" onClick={() => setMobileOpen(false)}>Simular Agora</a>
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  )
}
