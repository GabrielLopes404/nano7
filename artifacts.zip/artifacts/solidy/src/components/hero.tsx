import { motion } from "framer-motion"
import { PhoneCall } from "lucide-react"
import { Button } from "@/components/ui/button"

const WHATSAPP_URL = `https://wa.me/5561996059681?text=${encodeURIComponent("Olá! Gostaria de falar com um especialista da Solidy sobre proteção veicular.")}`

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden bg-background">
      <div className="pointer-events-none absolute inset-0">
        <motion.div
          className="absolute -right-40 -top-40 h-[500px] w-[500px] rounded-full bg-solidy-green/5"
          animate={{ scale: [1, 1.1, 1], rotate: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 12, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute -left-20 bottom-0 h-[350px] w-[350px] rounded-full bg-solidy-yellow/5"
          animate={{ scale: [1, 1.15, 1] }}
          transition={{ repeat: Infinity, duration: 10, ease: "easeInOut" }}
        />
      </div>

      <div className="relative mx-auto flex w-full max-w-7xl flex-col items-center gap-10 px-4 pt-28 pb-12 sm:px-6 lg:flex-row lg:gap-16 lg:pt-28 lg:pb-0">
        {/* Texto */}
        <div className="flex-1 text-center lg:text-left">
          <motion.h1
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="text-3xl font-bold leading-tight tracking-tight text-foreground sm:text-5xl lg:text-6xl"
          >
            {"Proteção Total para Seu Carro. "}
            <motion.span
              className="inline-block text-solidy-green"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              Tranquilidade em Cada Quilômetro.
            </motion.span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="mt-5 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg lg:text-xl"
          >
            Seguro auto inteligente, rápido e sem complicação. Simule em segundos e dirija com a tranquilidade que você merece.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.55 }}
            className="mt-8 flex flex-col items-center gap-3 sm:flex-row lg:justify-start"
          >
            <Button
              size="lg"
              className="w-full bg-solidy-green text-white hover:bg-solidy-green-hover px-8 py-6 text-base font-semibold sm:w-auto"
              asChild
            >
              <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">
                <PhoneCall className="mr-2 h-5 w-5" />
                Fale com Especialista
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="w-full border-solidy-green text-solidy-green hover:bg-solidy-green hover:text-white px-8 py-6 text-base font-semibold transition-all sm:w-auto"
              asChild
            >
              <a href="#simulacao">Simular Agora</a>
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.7 }}
            className="mt-8 flex items-center justify-center gap-6 lg:justify-start sm:gap-10"
          >
            {[
              { label: "Clientes protegidos", value: "50k+" },
              { label: "Avaliação média", value: "4.9" },
              { label: "Assistência total", value: "24h" },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                className="text-center"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 + i * 0.15 }}
              >
                <p className="text-xl font-bold text-foreground sm:text-2xl">{stat.value}</p>
                <p className="text-xs text-muted-foreground leading-snug">{stat.label}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Imagem */}
        <motion.div
          className="relative w-full flex-1 max-w-sm sm:max-w-none"
          initial={{ opacity: 0, x: 40 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.9, delay: 0.2 }}
        >
          <motion.div
            className="absolute inset-0 rounded-3xl bg-solidy-green/10"
            animate={{ scale: [1, 1.02, 1] }}
            transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
          />
          <div className="relative overflow-hidden rounded-3xl shadow-2xl">
            <img
              src="/images/hero-car.jpg"
              alt="Carro protegido pela Solidy"
              className="w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
            <div className="absolute bottom-4 left-4 flex items-center gap-2 rounded-xl bg-white/90 backdrop-blur-sm px-4 py-2.5 shadow-xl sm:bottom-6 sm:left-6 sm:rounded-2xl sm:px-5 sm:py-3">
              <div className="h-2.5 w-2.5 animate-pulse rounded-full bg-solidy-green" />
              <div>
                <p className="text-xs font-bold text-foreground">Proteção ativa</p>
                <p className="text-xs text-muted-foreground">Cobertura completa</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
